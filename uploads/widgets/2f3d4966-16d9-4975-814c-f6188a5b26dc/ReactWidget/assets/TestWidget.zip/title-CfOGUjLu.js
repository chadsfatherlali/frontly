import{j as r}from"./index-C-aA0lbL.js";const s=({title:t})=>r.jsx("h1",{children:t});export{s as default};
